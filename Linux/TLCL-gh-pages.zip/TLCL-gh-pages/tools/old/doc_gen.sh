Now I know how to use latex and pandoc, we can get a much prettier pdf
so the orginal script here in this file is obsolete and deleted

http://happycasts.net/episodes?tag_id=4
